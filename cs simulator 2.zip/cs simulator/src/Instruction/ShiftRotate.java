package Instruction;

import Memory.Memory;
import Registers.Registers;
import Utilities.DataTypeConvert;
import cs.simulator.simulator;

import java.util.Arrays;

public class ShiftRotate extends Instruction {
     Memory mem;
     Registers R;
     String address;
     int intGPR;
     int count;
     int al;
     int lr;

    //Shift and rotate should both be divided into four conditions. ">>" and ">>>" can be used into implementation of right shift,
    //while left shift rotate can only be implemented by data change for a String.
    // 0 represents for right, 1 represents for left.
    // 0 represents for arithmetic, 1 represents for logical.
    public void Shift() {
        System.out.println("shift");
        String registerValue = R.getGPR(intGPR);
        if (count == 0) {
        } else {
            int RegisterValue = DataTypeConvert.DecimalToBinary(Integer.parseInt(registerValue), 16);
            System.out.println(RegisterValue);
            int firstDigit = R.getGPR(intGPR).charAt(0);
            int[] shiftResult = new int[16];
            if (lr == 0) {//right
                if (al == 0) {//arithmetic
                    RegisterValue = RegisterValue >>> count;
                    registerValue = Integer.toBinaryString(RegisterValue);
                } else {//logical
                    RegisterValue = RegisterValue >> count;
                    registerValue = Integer.toBinaryString(RegisterValue);
                }
            } else {//left
                if (al == 0) {//arithmetic
                    for (int i = 0; i < 16 - count; i++) {
                        shiftResult[i] = registerValue.charAt(i + count);
                    }
                    for (int i = 16 - count; i < 16; i++) {
                        shiftResult[i] = '0';
                    }
                    shiftResult[0] = firstDigit;
                    registerValue = Arrays.toString(shiftResult);
                } else {//logical
                    for (int i = 0; i < 16 - count; i++) {
                        shiftResult[i] = registerValue.charAt(i + count);
                    }
                    registerValue = Arrays.toString(shiftResult);
                }
            }
        }
        R.setGPR(intGPR, registerValue);
        System.out.println("Register:"+intGPR);
        System.out.println(R.getGPR(intGPR));
        switch(intGPR)
        {
              case 0:
                {
                    cs.simulator.simulator.r0.setText(R.getGPR(intGPR));
                    cs.simulator.simulator.log.setText(cs.simulator.simulator.log.getText() + "Register value(R" + intGPR + ")" + ":");     //Log is used to display the description of what is happening to the values of MAR,MBR,IR,PC whenever we execute a instruction
            cs.simulator.simulator.log.setText(cs.simulator.simulator.log.getText() + "" + R.getGPR(intGPR));
                    break;
                }
                 case 1:
                {
                    cs.simulator.simulator.r1.setText(R.getGPR(intGPR));
                    cs.simulator.simulator.log.setText(cs.simulator.simulator.log.getText() + "Register value(R" + intGPR + ")" + ":");     //Log is used to display the description of what is happening to the values of MAR,MBR,IR,PC whenever we execute a instruction
            cs.simulator.simulator.log.setText(cs.simulator.simulator.log.getText() + "" + R.getGPR(intGPR));
                    break;
                }
                 case 2:
                {
                    cs.simulator.simulator.r2.setText(R.getGPR(intGPR));
                    cs.simulator.simulator.log.setText(cs.simulator.simulator.log.getText() + "Register value(R" + intGPR + ")" + ":");     //Log is used to display the description of what is happening to the values of MAR,MBR,IR,PC whenever we execute a instruction
            cs.simulator.simulator.log.setText(cs.simulator.simulator.log.getText() + "" + R.getGPR(intGPR));
                    break;
                }
                 case 3:
                {
                    cs.simulator.simulator.r3.setText(R.getGPR(intGPR));
                    cs.simulator.simulator.log.setText(cs.simulator.simulator.log.getText() + "Register value(R" + intGPR + ")" + ":");     //Log is used to display the description of what is happening to the values of MAR,MBR,IR,PC whenever we execute a instruction
            cs.simulator.simulator.log.setText(cs.simulator.simulator.log.getText() + "" + R.getGPR(intGPR));
                    break;
                }
                 default:
                     break;
                    
        }
    }

    public void Rotate() {//rotate instruction should be implemented as below:
        //1.store the numbers that will be replaced by others in result array
        //2.store the rest numbers in result array

        String registerValue = R.getGPR(intGPR);
        if (count != 0) {
            int firstDigit = R.getGPR(intGPR).charAt(0);
            int[] rotateResult = new int[16];
            if (lr == 0) {//right
                if (al == 0) {//arithmetic
                    for (int i = 0; i < 16 - count; i++) {
                        rotateResult[i + count] = registerValue.charAt(i);
                    }
                    for (int i = 0; i < count; i++) {
                        rotateResult[i] = registerValue.charAt(16 - count);
                    }
                    rotateResult[0] = firstDigit;
                    registerValue = Arrays.toString(rotateResult);
                } else {//logical
                    for (int i = 0; i < 16 - count; i++) {
                        rotateResult[i + count] = registerValue.charAt(i);
                    }
                    for (int i = 0; i < count; i++) {
                        rotateResult[i] = registerValue.charAt(16 - count);
                    }
                    registerValue = Arrays.toString(rotateResult);
                }
            } else {//left
                if (al == 0) {//arithmetic
                    for (int i = 0; i < 16 - count; i++) {
                        rotateResult[i] = registerValue.charAt(i + count);
                    }
                    for (int i = 16 - count; i < 16; i++) {
                        rotateResult[i] = registerValue.charAt(i - 16 + count);
                    }
                    rotateResult[0] = firstDigit;
                    registerValue = Arrays.toString(rotateResult);
                } else {//logical
                    for (int i = 0; i < 16 - count; i++) {
                        rotateResult[i] = registerValue.charAt(i + count);
                    }
                    for (int i = 16 - count; i < 16; i++) {
                        rotateResult[i] = registerValue.charAt(i - 16 + count);
                    }
                    registerValue = Arrays.toString(rotateResult);
                }
            }
        }
        R.setGPR(intGPR, registerValue);
    }

    public ShiftRotate(Registers register, Memory memory, String[] instruction) {
        mem = memory;
        R = register;
        intGPR = Integer.parseInt(instruction[1]);
        count = Integer.parseInt(instruction[2]);
        al = Integer.parseInt(instruction[3]);
        lr = Integer.parseInt(instruction[4]);
    }

    @Override
    public void Instruction(Registers register, Memory memory) {

    }
}
