import java.util.Arrays;

public class Test {
    public static void main(String args[]) {
        //String value = Integer.toBinaryString(12);
        //System.out.println("value: "+ value);
        //System.out.println(DataTypeConvert.intToString(12, 16));
        //System.out.println(DataTypeConvert.DecimalToBinary(12,16));
        Registers registers = new Registers();
        Memory mem = new Memory();
        registers.setGPR(1, "12");
        String[] instruction={"0","1","3","0","0"};
        Shift_Rotate sr= new Shift_Rotate(registers,mem,instruction);
        sr.Rotate();
    }
}
