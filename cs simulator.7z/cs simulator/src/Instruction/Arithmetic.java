package Instruction;

import Memory.Memory;
import Registers.Registers;
import Utilities.EffectiveAddress;
import cs.simulator.simulator;

public class Arithmetic extends Instruction{

    private Memory mem;
    private Registers R;
    simulator GUI;
    private String address;
    private int intGPR;
    String opCode;
    String GPR;
    String IX;
    String I;
    String immediate;
    public Arithmetic(Registers register, Memory memory, String[] instruction) throws Exception {
        R=register;
        mem=memory;

    }

    public void AMR(String[] instruction) throws Exception {
        GPR=instruction[1];
        IX=instruction[2];
        I=instruction[3];
        int intIX = Integer.parseInt(IX);
        int intI = Integer.parseInt(I);
        intGPR=Integer.parseInt(GPR);
        address = EffectiveAddress.computeEA(intI, intIX,instruction[4],R,mem);
        String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(intGPR), 2) + Integer.parseInt(address, 2)); // value = c(reg) + c(EA)
        R.setGPR(intGPR, value);                         // reg <- c(reg) + c(EA)
        R.incrementPC();
    }

    public void SMR(String[] instruction)throws Exception{
        GPR=instruction[1];
        IX=instruction[2];
        I=instruction[3];
        int intIX = Integer.parseInt(IX);
        int intI = Integer.parseInt(I);
        address = EffectiveAddress.computeEA(intI, intIX,instruction[4],R,mem);
        String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(intGPR), 2) + Integer.parseInt(address, 2)); // value = c(reg) + c(EA)
        R.setGPR(intGPR, value);                         // reg <- c(reg) + c(EA)
        R.incrementPC();
    }

    public void AIR(String[] instruction){
        GPR=instruction[1];
        intGPR=Integer.parseInt(GPR);
        immediate=instruction[2];
        String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(intGPR), 2) + Integer.parseInt(immediate, 2)); // value = c(reg) + immediate
        R.setGPR(intGPR, value);                         // reg <- c(reg) + immediate
        R.incrementPC();

    }
    public void SIR(String[] instruction){
        GPR=instruction[1];
        intGPR=Integer.parseInt(GPR);
        immediate=instruction[2];
        String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(intGPR), 2) - Integer.parseInt(immediate, 2)); // value = c(reg) - immediate
        R.setGPR(intGPR, value);                         // reg <- c(reg) - immediate
        R.incrementPC();
    }



    @Override
    public void Instruction(Registers register, Memory memory) {

    }
}
