package Instruction;

import Memory.Memory;
import Registers.Registers;
import Utilities.EffectiveAddress;
import cs.simulator.simulator;

public class Transfer extends Instruction{
    private Memory mem;
    private Registers R;
    simulator GUI;
    private String address;
    private int intGPR;

    public Transfer(Registers register, Memory memory, String[] instruction) throws Exception {
        R=register;
        mem=memory;
        String GPR = instruction[1];
        String IX = instruction[2];
        String i = instruction[3];
        int intIX = Integer.parseInt(IX);
        int intI = Integer.parseInt(i);
        intGPR=Integer.parseInt(GPR);
        address = EffectiveAddress.computeEA(intI, intIX,instruction[4],R,mem);
        intGPR=Integer.parseInt(GPR);
    }

    public void JZ(){
        if (Integer.parseInt(R.getGPR(intGPR), 2) == 0) {  // if c(reg) == 0, jump to address
            R.setPC(address);
        } else {                                         // else PC + 1
            R.incrementPC();
        }
    }
    public void JNE(){
        if (Integer.parseInt(R.getGPR(intGPR), 2) != 0) {  // if c(reg) != 0, jump to address
            R.setPC(address);
        } else {                                         // else PC + 1
            R.incrementPC();
        }
    }
    public void JCC(){
        if (R.getCC(intGPR).equals("1")) {                      // if of cc[intGPR] == 1, jump to address
            R.setPC(address);
        } else {                                         // else PC + 1
            R.incrementPC();
        }
    }
    public void JMA(){
        R.setPC(address);
    }
    public void JSR(){
        R.setGPR(3, R.incrementPC());                    // R3 <- PC + 1
        R.setPC(address);                                     // PC <- address
        // R0 should contain pointer to arguments
    }
    public void RFS() throws Exception {
        R.setGPR(0, mem.getMemValue(address));              // R0 <- return code
        R.setPC(R.getGPR(3));
    }
    public void SOB(){
        R.setGPR(intGPR, Integer.toBinaryString(Integer.parseInt(R.getGPR(intGPR), 2) - 1)); // reg <- c(reg) - 1
        if (Integer.parseInt(R.getGPR(intGPR), 2) > 0) {   // if c(reg) > 0, jump to address
            R.setPC(address);
        } else {                                         // else PC + 1
            R.incrementPC();
        }
    }
    public void JGE(){
        if (Integer.parseInt(R.getGPR(intGPR), 2) >= 0) {  // if c(reg) >= 0, jump to address
            R.setPC(address);
        } else {                                         // else PC + 1
            R.incrementPC();
        }
    }

    @Override
    public void Instruction(Registers register, Memory memory) {

    }


}
