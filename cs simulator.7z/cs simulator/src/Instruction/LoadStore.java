package Instruction;

import Memory.Memory;
import Registers.Registers;
import cs.simulator.simulator;

public class LoadStore extends Instruction {
    private Memory mem;
    private Registers reg;
    simulator GUI;
    private String address;
    private String IX;
    private String I;
    private String GPR;
    private int intAddress;
    private int intIX;
    private int intI;
    private int intGPR;


    public void LDR() throws Exception {
        reg.setGPR(intGPR,mem.getMemValue(address));
    }

    public void LDA() {
        reg.setGPR(intGPR,address);
    }

    public void LDX() throws Exception {
        reg.setXR(intIX,mem.getMemValue(address));
    }

    public void STR() throws Exception {
        mem.setMemValue(address,reg.getGPR(intGPR));
    }

    public void STX() throws Exception {
        mem.setMemValue(address,reg.getXR(intIX));
    }

    public LoadStore(Registers register, Memory memory, String[] instruction) { //get value from Decode
        reg=register;
        mem=memory;
        GPR = instruction[1];
        IX = instruction[2];
        address = instruction[3];
        intAddress=Integer.parseInt(address);
        intIX=Integer.parseInt(IX);
        intI= Integer.parseInt(I);
        intGPR=Integer.parseInt(GPR);
    }

    @Override
    public void Instruction(Registers register, Memory memory) {

    }
}
