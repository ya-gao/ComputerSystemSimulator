/* 
 * R is register object, M is memory object
 * opcode, reg, ireg etc are strings
 * addressnum, regnum and iregnum are decimal (registers and memory class takes in decimal register/address numbers)
 */

//====================================General Functions among instructions=================================================

// whichever instruction executed these steps are the same, so I put these outside the if-else to avoid repeating
// increment PC/jumping to another PC will be done in each instruction
R.setMAR(R.getPC()); // MAR <- PC
R.setMBR(M.getMem(Integer.parseInt(R.getMAR(), 2)));  // MBR <- getMem[MAR]
R.setIR(R.getMBR()); // IR <- MBR

// given i, ireg, and address, calculate effective address EA in binary string.
String EA = CalEA(...) 

/* This function adds leading zeros to binary strings until length of str reaches length
 * this func is needed because after some cumputation we get some binary strings shorter than its standard length,
 * we want some padding zeros so that the stadard size of strings can be assigned to registers
 */


//=====================================Miscellaneous Instructions (HLT and TRAP)========================================

/* HLT Instruction: opcode (0-5) + black (6-9) + oprand (10-15)
 * Stops the machine
 */
String instruction = opcode + black + oprand;
if opcode == "000000" && oprand == "000000" {
    R.incrementPC();     // PC + 1

    // ADD CODE HERE to stop the machine
}

/* Trap Instruction: opcode (0-5) + black (6-11) + trapcode (12-15)
 * Handout says this is for part 3
 */
String instruction = opcode + black + trapcode;
if opcode == "011110" {
    R.incrementPC();     // PC + 1
    
    // ADD CODE HERE to implement trap
}


// ==============================Transfer Instructions==========================================================

/* Transfer Instructions change control of program execution
 * The same format as Load/Store instructions: opcode (0-5) + reg (6-7) + ireg (8-9) + i (10) + address (11-15)
 */
String instruction = opcode + reg + ireg + i + address;

switch (opcode) {
    case "JZ": opcode = "001010"; break; 
    case "JNE": opcode = "001011"; break; 
    case "JCC": opcode = "001100"; break; 
    case "JMA": opcode = "001101"; break; 
    case "JSR": opcode = "001110"; break; 
    case "RFS": opcode = "001111"; break; 
    case "SOB": opcode = "010000"; break; 
    case "JGE": opcode = "010001"; break; 
    default: break;
} 

// if meets the condition, set PC to EA; otherwise increment PC by 1
if opcode == "001010" {                              // JZ: Jump If Zero
    if Integer.parseInt(R.getGPR(regnum), 2) == 0 {  // if c(reg) == 0, jump to EA
        R.setPC(EA);
    } else {                                         // else PC + 1
        R.incrementPC();
    }
} else if opcode == "001011" {                       // JNE: Jump If Not Equal
    if Integer.parseInt(R.getGPR(regnum), 2) != 0 {  // if c(reg) != 0, jump to EA
        R.setPC(EA);
    } else {                                         // else PC + 1
        R.incrementPC();
    }
} else if opcode == "001100" {                       // JCC: Jump If Condition Code
    if R.getCC(regnum) == "1" {                      // if of cc[regnum] == 1, jump to EA
        R.setPC(EA);
    } else {                                         // else PC + 1
        R.incrementPC();
    }
} else if opcode == "001101" {                       // JMA: Unconditional Jump To Address
    R.setPC(EA);
} else if opcode == "001110" {                       // JSR: Jump and Save Return Address
    R.setGPR(3, R.incrementPC());                    // R3 <- PC + 1
    R.setPC(EA);                                     // PC <- EA
    // R0 should contain pointer to arguments
} else if opcode == "001111" {                       // RFS: return from subroutine with return code stored in address
    R.setGPR(0, M.get.Mem(addressnum));              // R0 <- return code
    R.setPC(R.getGPR(3));                            // PC <- R3
} else if opcode == "010000" {                       // SOB: Subtract One and Branch
    R.setGPR(regnum, Integer.toBinaryString(Integer.parseInt(R.getGPR(regnum), 2) - 1)) // reg <- c(reg) - 1
    if Integer.parseInt(R.getGPR(regnum), 2) > 0 {   // if c(reg) > 0, jump to EA
        R.setPC(EA);
    } else {                                         // else PC + 1
        R.incrementPC();
    }
} else if opcode == "010001" {                       // JGE: Jump Grater Than or Equal To
    if Integer.parseInt(R.getGPR(regnum), 2) >= 0 {  // if c(reg) >= 0, jump to EA
        R.setPC(EA);
    } else {                                         // else PC + 1
        R.incrementPC();
    }
}


// ==============================Arithmetic and Logic Instructions===============================================

// Arithmetic&Logic Instructions (Intermediate, register-regiter, and shift/rotate opration) performs computational works

/* Intermediate instructions has the same format as Load/Store instructions: 
 * opcode (0-5) + reg (6-7) + ireg (8-9) + i (10) + immediate (11-15)
 */
String instruction = opcode + reg + ireg + i + immediate;

switch (opcode) {
    case "AMR": opcode = "000100"; break; 
    case "SMR": opcode = "000101"; break; 
    case "AIR": opcode = "000110"; break; 
    case "SIR": opcode = "000111"; break; 
    default: break;
}

if opcode == "000100" {                              // AMR: Add Memory To Register
    String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(regnum), 2) + Integer.parseInt(EA, 2)); // value = c(reg) + c(EA)
    R.setGPR(regnum, value);                         // reg <- c(reg) + c(EA)
    R.incrementPC();
} else if opcode == "000101" {                       // SMR: Subtract Memory From Register
    String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(regnum), 2) - Integer.parseInt(EA, 2)); // value = c(reg) - c(EA)
    R.setGPR(regnum, value);                         // reg <- c(reg) - c(EA)
    R.incrementPC();
} else if opcode == "000110" {                       // AIR: Add Immediate To Register
    String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(regnum), 2) + Integer.parseInt(immediate, 2)); // value = c(reg) + immediate
    R.setGPR(regnum, value);                         // reg <- c(reg) + immediate
    R.incrementPC();
} else if opcode == "000111" {                       // SIR: Subtract Immediate To Register
    String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(regnum), 2) - Integer.parseInt(immediate, 2)); // value = c(reg) - immediate
    R.setGPR(regnum, value);                         // reg <- c(reg) - immediate
    R.incrementPC();
} 


/* Register-register instructions: opcode (0-5) + rx (6-7) + ry (8-9) + black (10-15)
 */
String instruction = opcode + rx + ry + black;

switch (opcode) {
    case "MLT": opcode = "010100"; break; 
    case "DVD": opcode = "010101"; break; 
    case "TRR": opcode = "010110"; break; 
    case "AND": opcode = "010111"; break; 
    case "ORR": opcode = "011000"; break; 
    case "NOT": opcode = "011001"; break; 
    default: break;
}

if opcode == "010100" {                              // MLT: Multiply Register by Register
    String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(rxnum), 2) * Integer.parseInt(rynum, 2)); // value = c(rx)* c(ry)
    if R.setGPR(regnum, value) == Valid {            // if no overflow, rx + 1 <- result. 
        // Valid and Overflow are declared in Registers class
        R.setGPR(rxnum + 1, padding(value, 16));
        R.incrementPC();
    } else if R.setGPR(regnum, value) == Overflow {  // if Overflow, rx <- higher order bits, rx+1 <- lower order bits
        // seperate the product into overflow and result
        String overflow = padding(value.substring(0, len(value) - 16), 16);
        String result = padding(value.substring(len(value) - 16), 16);
        // rx <- overflow, rx + 1 <- result
        R.setGPR(rxnum, overflow);
        R.setGPR(rnum + 1, result);
        // set OVERFLOW Flag (set cc[0] to 1)
        R.serCC(0, "1");
        R.incrementPC();
    }
} else if opcode == "010101" {                       // DVD: Divide Register by Register
    if Integer.parseInt(R.getGPR(rynum), 2) == 0 {   // if ry == 0, set DIVZERO flag (set CC[2] to 1)
        R.setCC(2, "1");
        R.incrementPC();
    } else {
        // do division in integer format
        int quotient = Integer.parseInt(R.getGPR(rxnum), 2) / Integer.parseInt(rynum, 2); 
        int remainder = Integer.parseInt(R.getGPR(rxnum), 2) % Integer.parseInt(rynum, 2); 
        // convert integer results into binary strings with atandard size
        String quo = padding(Interger.toBinaryString(quotient));
        String rem = padding(Interger.toBinaryString(remainder));
        // rx <- quotient, ry <- remainder
        R.setGPR(rxnum, quo);                       
        R.setGPR(rynum, rem);                       
        R.incrementPC();
    }  
} else if opcode == "010110" {                       // TRR: Test the Equality of Register and Register
    if R.getGPR(rxnum) == R.getGPR(rynum) {          // if rx == ry, CC[3] <- 1 
        R.setCC(3, "1");
        R.incrementPC();
    } else {                                         // else CC[3] <- 0
        R.setCC(3, "0");
        R.incrementPC();
    }                  
} else if opcode == "010111" {                       // AND: Logical AND of Register and Register
    if Integer.parseInt(R.getGPR(rxnum), 2) != 0 && Integer.parseInt(R.getGPR(rynum), 2) != 0 {
        R.setGPR(rxnum, padding("1", 16));           // if c(rx) AND c(ry) is True, rx <- 1
        R.incrementPC();
    } else {                                         // else, rx <- 0
        R.setGPR(rxnum, padding("0", 16));
        R.incrementPC();
    }
} else if opcode == "011000" {                       // ORR: Logical OR of Register and Register
    if Integer.parseInt(R.getGPR(rxnum), 2) == 0 && Integer.parseInt(R.getGPR(rynum), 2) == 0 {
        R.setGPR(rxnum, padding("0", 16));           // if c(rx) OR c(ry) is False, rx <- 0
        R.incrementPC();
    } else {                                         // else, rx <- 1
        R.setGPR(rxnum, padding("1", 16));
        R.incrementPC();
    }
} else if opcode == "011001" {                       // NOT: Logical NOT of Register and Register
    if Integer.parseInt(R.getGPR(rxnum), 2) == 0 {   // if c(rx) == 0, rx <- 1
        R.setGPR(rxnum, padding("1", 16));           
        R.incrementPC();
    } else {                                         // else, rx <- 0
        R.setGPR(rxnum, padding("0", 16));
        R.incrementPC();
    }
} 


/* Shift/Rotate instructions: opcode (0-5) + reg (6-7) + al (8) + lr (9) + black (10-11) + count (12-15)
 */
String instruction = opcode + reg + al + lr + black + count;

switch (opcode) {
    case "SRC": opcode = "011111"; break; 
    case "RRC": opcode = "100000"; break; 
    default: break;
}

if opcode == "011111" {                              // SRC: Shift Register by Count
    String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(regnum), 2) + Integer.parseInt(EA, 2)); // value = c(reg) + c(EA)
    R.setGPR(regnum, value);                         // reg <- c(reg) + c(EA)
    R.incrementPC();
} else if opcode == "100000" {                       // RRC: Rotate Register by Count
    String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(regnum), 2) - Integer.parseInt(EA, 2)); // value = c(reg) - c(EA)
    R.setGPR(regnum, value);                         // reg <- c(reg) - c(EA)
    R.incrementPC();
} 