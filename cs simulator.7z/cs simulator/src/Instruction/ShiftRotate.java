package Instruction;

import Memory.Memory;
import Registers.Registers;
import cs.simulator.simulator;

public class ShiftRotate extends Instruction {
    private Memory mem;
    private Registers R;
    simulator GUI;
    private String address;
    private int intGPR;
    @Override
    public void Instruction(Registers register, Memory memory) {

    }
}
