package Instruction;

import Memory.Memory;
import Registers.Registers;
import Utilities.EffectiveAddress;
import cs.simulator.simulator;

import static Utilities.DataTypeConvert.padding;

public class Logical extends Instruction{
    private Memory mem;
    private Registers R;
    simulator GUI;
    private String address;
    private int intGPR;
    private int RX;
    private int RY;

    public Logical(Registers register, Memory memory, String[] instruction) throws Exception {
        R=register;
        mem=memory;
        RX=Integer.parseInt(instruction[1]);
        RY=Integer.parseInt(instruction[2]);
    }

    public void MLT(){
        String value = Integer.toBinaryString(Integer.parseInt(R.getGPR(RX), 2) * Integer.parseInt(R.getGPR(RY), 2)); // value = c(rx)* c(ry)
        if (R.setGPR(RY, value) == Valid) {            // if no overflow, rx + 1 <- result.
            // Valid and Overflow are declared in Registers class
            R.setGPR(RX + 1, padding(value, 16));
            R.incrementPC();
        } else if (R.setGPR(RY, value) == Overflow) {  // if Overflow, rx <- higher order bits, rx+1 <- lower order bits
            // seperate the product into overflow and result
            String overflow = padding(value.substring(0, len(value) - 16), 16);
            String result = padding(value.substring(len(value) - 16), 16);
            // rx <- overflow, rx + 1 <- result
            R.setGPR(RX, overflow);
            R.setGPR(rnum + 1, result);
            // set OVERFLOW Flag (set cc[0] to 1)
            R.setCC(0, "1");
            R.incrementPC();
        }
    }
    public void DVD(){
        if (Integer.parseInt(R.getGPR(RY), 2) == 0 ){   // if ry == 0, set DIVZERO flag (set CC[2] to 1)
            R.setCC(2, "1");
            R.incrementPC();
        } else {
            // do division in integer format
            int quotient = Integer.parseInt(R.getGPR(RX), 2) / Integer.parseInt(R.getGPR(RY), 2);
            int remainder = Integer.parseInt(R.getGPR(RX), 2) % Integer.parseInt(R.getGPR(RY), 2);
            // convert integer results into binary strings with atandard size
            String quo = padding(Interger.toBinaryString(quotient));
            String rem = padding(Interger.toBinaryString(remainder));
            // rx <- quotient, ry <- remainder
            R.setGPR(RX, quo);
            R.setGPR(RY, rem);
            R.incrementPC();
        }
    }
    public void TRR(){
        if (R.getGPR(RX) == R.getGPR(RY)) {          // if rx == ry, CC[3] <- 1
            R.setCC(3, "1");
            R.incrementPC();
        } else {                                         // else CC[3] <- 0
            R.setCC(3, "0");
            R.incrementPC();
        }
    }
    public void AND(){
        if (Integer.parseInt(R.getGPR(RX), 2) != 0 && Integer.parseInt(R.getGPR(RY), 2) != 0) {
            R.setGPR(RX, padding("1", 16));           // if c(rx) AND c(ry) is True, rx <- 1
            R.incrementPC();
        } else {                                         // else, rx <- 0
            R.setGPR(RX, padding("0", 16));
            R.incrementPC();
        }
    }
    public void ORR(){
        if (Integer.parseInt(R.getGPR(RX), 2) == 0 && Integer.parseInt(R.getGPR(RY), 2) == 0 ){
            R.setGPR(RX, padding("0", 16));           // if c(rx) OR c(ry) is False, rx <- 0
            R.incrementPC();
        } else {                                         // else, rx <- 1
            R.setGPR(RX, padding("1", 16));
            R.incrementPC();
        }
    }
    public void NOT(){
        if (Integer.parseInt(R.getGPR(RX), 2) == 0 ){   // if c(rx) == 0, rx <- 1
            R.setGPR(RX, padding("1", 16));
            R.incrementPC();
        } else {                                         // else, rx <- 0
            R.setGPR(RX, padding("0", 16));
            R.incrementPC();
        }
    }
    @Override
    public void Instruction(Registers register, Memory memory) {

    }
}
