package Utilities;

public class Decode {//to decode an instruction written in English into binary code

    public static String[] decodeForLoadStore(String instruction) { // Decoding method for Load and Store
        String opCode = instruction.substring(0, 3);      //split the string into sub parts using substring method
        String GPR = instruction.substring(4, 5);
        String IX = instruction.substring(6, 7);
        String I = instruction.substring(8, 9);
        String Address = instruction.substring(10);

        switch (opCode) {                        //Checking for opCode value and setting the value to it because opCode values are predefined
            case "LDR":
                opCode = "000001";
                break;
            case "STR":
                opCode = "000010";
                break;
            case "LDA":
                opCode = "000011";
                break;
            case "LDX":
                opCode = "101001";
                break;
            case "STX":
                opCode = "101010";
                break;
            default:
                break;
        }

        switch (GPR) {                      //Checking for register value
            case "0":
                GPR = "00";
                break;
            case "1":
                GPR = "01";
                break;
            case "2":
                GPR = "10";
                break;
            case "3":
                GPR = "11";
                break;
            default:
                break;
        }
        switch (IX) {                         // checking for index register value
            case "0":
                IX = "00";
                break;
            case "1":
                IX = "01";
                break;
            case "2":
                IX = "10";
                break;
            case "3":
                IX = "11";
                break;
            default:
                break;
        }

        int decimalAddress = Integer.parseInt(Address);
        String strBinaryAddress = Integer.toBinaryString(decimalAddress);
        int binaryAddress = Integer.parseInt(strBinaryAddress);
        int count = 0;
        while (binaryAddress > 0) {
            binaryAddress = binaryAddress / 10;
            count = count + 1;

        }
        int count1 = 5 - count;
        while (count1 != 0) {//This is to format the digits of the binaryAddress.
            strBinaryAddress = 0 + strBinaryAddress;
            count1--;
        }

        String[] instructionArray = {opCode, GPR, IX, I, strBinaryAddress};
        return instructionArray;
    }

    public static String[] decodeForArithmetic(String instruction) {
        String opCode = instruction.substring(0, 3);      //split the string into sub parts using substring method
        String GPR = instruction.substring(4, 5);

        switch (GPR) {                      //Checking for register value
            case "0":
                GPR = "00";
                break;
            case "1":
                GPR = "01";
                break;
            case "2":
                GPR = "10";
                break;
            case "3":
                GPR = "11";
                break;
            default:
                break;
        }

        switch (opCode) {
            case "AMR": {
                opCode = "000100";
                String IX = instruction.substring(6, 7);
                String I = instruction.substring(8, 9);
                String Address = instruction.substring(10);
                int decimalAddress = Integer.parseInt(Address);
                String strBinaryAddress = DataTypeConvert.intToString(decimalAddress, 6);
                String[] instructionArray = {opCode, GPR, IX, I, strBinaryAddress};
                return instructionArray;
            }
            case "SMR": {
                opCode = "000101";
                String IX = instruction.substring(6, 7);
                String I = instruction.substring(8, 9);
                String Address = instruction.substring(10);
                int decimalAddress = Integer.parseInt(Address);
                String strBinaryAddress = DataTypeConvert.intToString(decimalAddress, 6);
                String[] instructionArray = {opCode, GPR, IX, I, strBinaryAddress};
                return instructionArray;
            }
            case "AIR": {
                opCode = "000110";
                String immediate = instruction.substring(6);
                String[] instructionArray = {opCode, GPR, immediate};
                return instructionArray;
            }
            case "SIR": {
                opCode = "000111";
                String immediate = instruction.substring(6);
                String[] instructionArray = {opCode, GPR, immediate};
                return instructionArray;
            }
            default:
                return null;
        }


// if meets the condition, set PC to EA; otherwise increment PC by 1
    }

    public String[] decodeForTransfer(String instruction) {
        String opCode = instruction.substring(0, 3);      //split the string into sub parts using substring method
        String GPR = instruction.substring(4, 5);
        String IX = instruction.substring(6, 7);
        String I = instruction.substring(8, 9);
        String Address = instruction.substring(10);

        switch (opCode) {
            case "JZ ":
                opCode = "001010";
                break;
            case "JNE":
                opCode = "001011";
                break;
            case "JCC":
                opCode = "001100";
                break;
            case "JMA":
                opCode = "001101";
                break;
            case "JSR":
                opCode = "001110";
                break;
            case "RFS":
                opCode = "001111";
                break;
            case "SOB":
                opCode = "010000";
                break;
            case "JGE":
                opCode = "010001";
                break;
            default:
                break;
        }

        switch (GPR) {                      //Checking for register value
            case "0":
                GPR = "00";
                break;
            case "1":
                GPR = "01";
                break;
            case "2":
                GPR = "10";
                break;
            case "3":
                GPR = "11";
                break;
            default:
                break;
        }
        switch (IX) {                         // checking for index register value
            case "0":
                IX = "00";
                break;
            case "1":
                IX = "01";
                break;
            case "2":
                IX = "10";
                break;
            case "3":
                IX = "11";
                break;
            default:
                break;
        }
        int decimalAddress = Integer.parseInt(Address);
        String strBinaryAddress = DataTypeConvert.intToString(decimalAddress, 6);

        return new String[]{opCode, GPR, IX, I, strBinaryAddress};
    }

    public static String[] decodeForLogical(String instruction) {
        String opCode = instruction.substring(0, 3);      //split the string into sub parts using substring method
        String RX = instruction.substring(4, 5);
        String RY = "";
        switch (opCode) {
            case "MLT":
                opCode = "010100";
                RY = instruction.substring(6, 7);
                break;
            case "DVD":
                opCode = "010101";
                RY = instruction.substring(6, 7);
                break;
            case "TRR":
                opCode = "010110";
                RY = instruction.substring(6, 7);
                break;
            case "AND":
                opCode = "010111";
                RY = instruction.substring(6, 7);
                break;
            case "ORR":
                opCode = "011000";
                RY = instruction.substring(6, 7);
                break;
            case "NOT":
                opCode = "011001";
                RY=""; //RY is not used here, so I set it as null to avoid null pointer.
                break;
            default:
                break;
        }
        return new String[]{opCode,RX,RY};
    }

    public static String[] ShiftRotate(String instruction){
        //opcode (0-5) + reg (6-7) + al (8) + lr (9) + black (10-11) + count (12-15);
        String opCode=instruction.substring(0,5);
        String GPR=instruction.substring(0,5);
        String AL=instruction.substring(0,5);
        String LR=instruction.substring(0,5);
        String BLACK=instruction.substring(0,5);
        String COUNT=instruction.substring(0,5);
        return null;
    }
}

