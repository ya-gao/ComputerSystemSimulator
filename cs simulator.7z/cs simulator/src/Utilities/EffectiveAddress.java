package Utilities;

import Memory.Memory;
import Registers.Registers;

public class EffectiveAddress {
    public static String computeEA(int I, int IX, String Address, Registers reg, Memory mem) throws Exception {
        //Address here should be binary String type
        String EA = new String();
        if (I == 0) {
            // No indirect addressing
            if (IX == 00) {
                // EA = content of the Address field
                EA = mem.getMemValue(Address);
            } else if (IX == 01 || IX == 02 || IX == 03) {
                //Calculating EA = c(IX) + c(Address)
                EA = Integer.toBinaryString(Integer.parseInt(reg.getXR(IX)) + Integer.parseInt(mem.getMemValue(Address), 2));
            }
        } else {
            if (IX == 0) {
                // indirect addressing, but NO indexing, EA = c(Address)
                EA = mem.getMemValue(Address);
            } else {
                //Both indirect addressing and indexing, EA = c(c(IX) + Address)
                EA = Integer.toBinaryString(Integer.parseInt(reg.getXR(IX)) + Integer.parseInt(mem.getMemValue(Address), 2));
            }
        }
        return EA;
    }

}

