package Utilities;

public class DataTypeConvert {
    public static String intToString(int num, int addressSize){//decimal Integer to binary String
        String value = Integer.toBinaryString(num);
        String formatter = "%" + addressSize + "s";
        return String.format(formatter, value).replace(' ', '0');
    }
    public static String padding(String str, int length) {
        if (length == 16) {
            str = String.format("%016d", Integer.parseInt(str));
        } else if (length == 12) {
            str = String.format("%012d", Integer.parseInt(str));
        } else if (length == 4) {
            str = String.format("%04d", Integer.parseInt(str));
        }
        return str;
    }
}
