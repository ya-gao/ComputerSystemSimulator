/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program;

import Memory.Memory;
import Registers.Registers;
import Utilities.Decode;
import cs.simulator.simulator;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author dilipvarma
 */
public class program1 {
     String opcode;
     String ins;
    
     Registers r=new Registers();
     Memory m=new Memory();
   // Decode dc=new Decode(r,m);
    public void readFile() {
        File file = new File("./program1.txt");
        BufferedReader reader = null;
        String[] insArray=new String[106];
        try {
            reader = new BufferedReader(new FileReader(file));
            String tempString ;
            int i=0;
            while ((tempString = reader.readLine()) != null) {
                insArray[i]=tempString;
                i++;
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
       // System.out.println("HI");
        for(int j=0;j<insArray.length;j++)
        {
            Decode dc=new Decode(r,m);
            System.out.println(insArray[j]);
            ins=insArray[j];
             opcode=ins.substring(0,3);
            if(opcode.equals("LDR")||opcode.equals("STR")||opcode.equals("LDA")||opcode.equals("LDX")||opcode.equals("STX"))
            { 
              //  System.out.println("Test");
                try {
                  //  System.out.println("Test1");
                    dc.decodeForLoadStore(ins);
                   // System.out.println("Test2");
                } catch (Exception ex) {
                    Logger.getLogger(simulator.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
            else if(opcode.equals("AMR")||opcode.equals("SMR")||opcode.equals("AIR")||opcode.equals("SIR"))
            {
                System.out.println("SMR");
                try {
                    
                    dc.decodeForArithmetic(ins);
                } catch (Exception ex) {
                    Logger.getLogger(simulator.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
            
            else if(opcode.equals("JZ ")||opcode.equals("JNE")||opcode.equals("SOB")||opcode.equals("JGE")||opcode.equals("JMA")||opcode.equals("JSR")||opcode.equals("RFS"))//||opcode.equals("JCC"))
            {
                 try {
                   
                    dc.decodeForTransfer(ins);
                } catch (Exception ex) {
                    Logger.getLogger(simulator.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
            else if(opcode.equals("MLT")||opcode.equals("MIN")||opcode.equals("DVD")||opcode.equals("TRR")||opcode.equals("AND")||opcode.equals("ORR")||opcode.equals("NOT"))
            {
                try {
                   
                    dc.decodeForLogical(ins);
                } catch (Exception ex) {
                    Logger.getLogger(simulator.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else 
            {
                if(opcode.equals("IN "))
                {
                //JFrame frame1=new JFrame();
               System.out.println("IN");
               String inputValue = JOptionPane.showInputDialog("Please input a value");
               
                try {
                   
                    dc.decodeForIO(ins,inputValue);
                } catch (Exception ex) {
                    Logger.getLogger(simulator.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                else if(opcode.equals("OUT")){
                    System.out.println("OUT");
                    try {
                   
                    dc.decodeForIO(ins," ");
                } catch (Exception ex) {
                    Logger.getLogger(simulator.class.getName()).log(Level.SEVERE, null, ex);
                }
                }
            
            }
          
        
        if(j==insArray.length)
        {
            break;
        }
           // System.out.println(s);
            
        }
        
        //return insArray;
    }
}
