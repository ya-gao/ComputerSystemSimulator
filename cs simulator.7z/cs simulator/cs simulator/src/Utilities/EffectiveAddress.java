package Utilities;

import Memory.Memory;
import Registers.Registers;

public class EffectiveAddress {

    public static String computeEA(int I, int IX, String Address, Registers reg, Memory mem) throws Exception {
        //Address here should be binary String type
        String EA = new String();
        if (checkMachineFault(Address, mem))

            // System.out.println(mem.getMemValue(Address));
        if (I == 0) {
            // No indirect addressing
            //System.out.println("I");
            if (IX == 0) {
                // EA = content of the Address field
                System.out.println("Entered EA");
                EA = Address;
                System.out.println(EA);
                
            } else if (IX == 1 || IX == 2 || IX == 3) {
                //Calculating EA = c(IX) + c(Address)
                System.out.println("Entered EA1");
                
                EA = String.valueOf((Integer.parseInt(reg.getXR(IX)) + Integer.parseInt(Address)));
                //System.out.println(EA);
            }
        } else {
            if (IX == 0) {
                // indirect addressing, but NO indexing, EA = c(Address)
                EA = mem.getMemValue(Address);
            } else {
                //Both indirect addressing and indexing, EA = c(c(IX) + Address)
                EA = String.valueOf((Integer.parseInt(reg.getXR(IX)) + Integer.parseInt(Address)));
            }
        }
        
        return EA;
    }
    public static boolean checkMachineFault(String Address, Memory mem) throws MachineFaultException {
        // This function is to check whether the address in an instruction is legal and throw Exception if illegal
        int address = Integer.parseInt(Address);
        // whether it is a reserved location in memory
        if (address < 6) {
            throw new MachineFaultException(MachineFaultException.FaultCode.ILL_MEM_RSV.getValue(),
                    MachineFaultException.FaultCode.ILL_MEM_RSV.getMessage());
            // whether it is beyond the size of the memory
        } else if (address > mem.getMemoryCapacity() - 1) {
            throw new MachineFaultException(MachineFaultException.FaultCode.ILL_MEM_BYD.getValue(),
                    MachineFaultException.FaultCode.ILL_MEM_BYD.getMessage());
        } else {// Address is legal
            return true;
        }
    }

}

